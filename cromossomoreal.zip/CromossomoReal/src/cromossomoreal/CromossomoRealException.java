/*
 * CromossomoRealException.java
 *
 * Created on 4 de Fevereiro de 2006, 15:06
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package cromossomoreal;

/**
 *
 * @author Ricardo
 */
public class CromossomoRealException extends Exception {
    
    /** Creates a new instance of CromossomoRealException */
    public CromossomoRealException() {
        super();
    }
    
    public CromossomoRealException(String s) {
        super(s);
    }
    
}
