public class testaGA {
	public static void main(String args[]) {
	   GAUniforme meuGA=new GAUniforme(50,100,0.01);
	   meuGA.executa();
	}
}