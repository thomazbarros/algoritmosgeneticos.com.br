/*
 * CromossomoGAOrdem.java
 *
 * Created on 21 de Janeiro de 2006, 11:05
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package gaordem;

import java.util.*;
import java.lang.Math.*;


/**
 *
 * @author Ricardo
 */
public class CromossomoGAOrdem {
    
int cidades[];
    /**Cria um novo cromossomo para o GA baseado em ordem. 
     *@param num n�mero de cidades que o cromossomo deve armazenar.
     */
    public CromossomoGAOrdem(int num) {
        Vector aux=new Vector();
        int i,j;        
        cidades=new int[num];
        //Cria um vetor auxiliar que vai servir para nos ajudar
        //a escolher os n�meros a serem colocados dentro do 
        //nosso vetor
        for(j=0;j<num;j++) {
            aux.add(new Integer(1+j));
        }
        j=0;
        while (aux.size()>0) {
            //Escolhe um n�mero dentro do vetor
            i=(int) Math.round(Math.random()*aux.size());            
            if (i==aux.size()) {i--;}
            //coloca-o no array e apaga-o do vetor, garantindo
            //que n�o teremos cidades duplicadas no array.
            cidades[j++]=((Integer) aux.get(i)).intValue();
            aux.remove(i);            
        }
    }
    
    /**
     *Realiza a muta��o em um cromossomo causando disrup��es aleat�rias em
     *um peda�o do mesmo.
     */
    public void mutacaoMisturaSublista() {
        int i,j,inicio,fim;        
        inicio=(int) Math.round(Math.random()*cidades.length);
        if (inicio==cidades.length) {inicio--;}
        fim=inicio+(int) Math.round(Math.random()*(cidades.length-inicio));
        if (fim==cidades.length) {fim--;}        
        Vector aux=new Vector();
        //copia as cidades na ordem invertida para o array auxiliar
        for (i=inicio;i<=fim;i++) {
            aux.add(new Integer(cidades[i]));
        }
        j=inicio;        
        while (aux.size()>0) {            
            //Escolhe um n�mero dentro do vetor
            i=(int) Math.round(Math.random()*aux.size());            
            if (i==aux.size()) {i--;}            
            //coloca-o no array e apaga-o do vetor, garantindo
            //que n�o teremos cidades duplicadas na sublista.
            cidades[j]=((Integer) aux.get(i)).intValue();
            aux.remove(i);            
            j++;
        }
    }
    
    /**
     *Realiza a muta��o em um cromossomo invertendo um peda�o do mesmo. � o operador
     *de muta��o que causa a disrup��o no menor n�mero de arestas (considerando
     *o problema sim�tico).
     */
    public void mutacaoInversao() {
        int i,inicio,fim;        
        inicio=(int) Math.round(Math.random()*cidades.length);
        if (inicio==cidades.length) {inicio--;}
        fim=inicio+(int) Math.round(Math.random()*(cidades.length-inicio));
        if (fim==cidades.length) {fim--;}                
        int aux[]=new int[fim-inicio+1];
        //copia as cidades na ordem invertida para o array auxiliar
        for (i=inicio;i<=fim;i++) {
            aux[i-inicio]=cidades[fim-i+inicio];
        }
        //copia as cidades em uma ordem aletat�ria de volta para o array
        for (i=inicio;i<=fim;i++) {
            cidades[i]=aux[i-inicio];
        }        
    }
    
    /**
     *Realiza a muta��o invertendo a posi��o de apenas dois elementos sorteados
     *de forma aleat�ria dentro do cromossomo. Causa a disrup��o de at� 4 arestas.
     */
    public void mutacaoInv2() {
        int i,inicio,fim;
        inicio=(int) Math.round(Math.random()*cidades.length);
        if (inicio==cidades.length) {inicio--;}
        fim=inicio;
        i=0;
        while ((fim==inicio)&&(i<3)) {
            fim=inicio+(int) Math.round(Math.random()*(cidades.length-inicio));
            if (fim==cidades.length) {fim--;}                
            i++;
        }
        i=cidades[inicio];
        cidades[inicio]=cidades[fim];
        cidades[fim]=i;
    }
    
    /**
     *Imprime o conte�do do cromossomo (cidades na ordem visitada).
     */
    public String toString() {
        int i;
        String s="";
        for(i=0;i<cidades.length;i++) {
            s=s+cidades[i];
            if (i<(cidades.length-1)) {s=s+"-";}
        }
        return(s);
    }
    
    public CromossomoGAOrdem crossoverOrdem(CromossomoGAOrdem outro) {
        CromossomoGAOrdem retorno=new CromossomoGAOrdem(this.cidades.length);
        int i,j,inicio,fim;
        Vector v=new Vector();
        inicio=(int) Math.round(Math.random()*cidades.length);
        if (inicio==cidades.length) {inicio--;}
        fim=inicio+(int) Math.round(Math.random()*(cidades.length-inicio));        
        if (fim==cidades.length) {fim--;}                
        System.out.println(inicio+"   "+fim);
        for(i=0;i<cidades.length;i++) {
            if ((i<inicio)||(i>fim)) {
               v.add(new Integer(this.cidades[i]));               
            } else {
               retorno.cidades[i]=this.cidades[i]; 
            }            
        }
        j=0;
        for(i=0;i<cidades.length;i++) {
            if (j==inicio) {j=fim+1;}
            if (v.indexOf(new Integer(outro.cidades[i]))>=0) {
                retorno.cidades[j]=outro.cidades[i];
                j++;
            }
        }
        return(retorno);
    }
    
    public CromossomoGAOrdem edgeRecombination(CromossomoGAOrdem outro) {
        CromossomoGAOrdem retorno=new CromossomoGAOrdem(this.cidades.length);
        int i,j,k, prox_cidade, tam_prox;
        int tam=this.cidades.length;
        int cid_corrente;
        Vector ja_usadas=new Vector();
        //Cria os vetores que v�o armazenar as arestas
        Vector v[]=new Vector[tam];
        for (i=0;i<tam;i++) {            
            v[i]=new Vector();            
        }
        //cria a lista de arestas
        for (i=0;i<tam;i++) {                   
            v[this.cidades[i]-1].add(new Integer(this.cidades[(i+1)%tam]));            
            v[this.cidades[(i+1)%tam]-1].add(new Integer(this.cidades[i]));
            v[outro.cidades[i]-1].add(new Integer(outro.cidades[(i+1)%tam]));
            v[outro.cidades[(i+1)%tam]-1].add(new Integer(outro.cidades[i]));
            
        }
        
        //Come�a a recombina��o de arestas
        cid_corrente=this.cidades[0];
        k=0;
        while (ja_usadas.size()<tam) {
            System.out.print("Cidade corrente: "+cid_corrente);
            //Imprime as arestas
            for (i=0;i<tam;i++) {
                System.out.print((i+1)+":");
                for (j=0;j<v[i].size();j++) {
                    System.out.print(v[i].get(j)+"-");
                }
                System.out.println(" ");
            }
            
            //coloca a cidade corrente na posi��o correta
            retorno.cidades[k]=cid_corrente;
            k++;
            
            System.out.println(" ");
            System.out.println(" ");
            for (i=0;i<k;i++) {
                System.out.print("Neste momento, o retorno �:");
                for (j=0;j<ja_usadas.size();j++) {
                    System.out.print(retorno.cidades[j]+"-");
                }
                System.out.println(" ");
            }
            
            //acrescenta a cidade corrente � lista de cidades usadas
            ja_usadas.add(new Integer(cid_corrente));
            //remove a cidade corrente de todas as listas de adjac�ncias
            for (i=0;i<tam;i++) {
                j=0;                
                while(j>=0) {
                    j=v[i].indexOf(new Integer(cid_corrente));
                    if (j>=0) {
                        v[i].remove(j);
                    }
                }
            }
            //escolhe a pr�xima cidade
            if (v[cid_corrente-1].size()>0) {
                prox_cidade=((Integer) v[cid_corrente-1].get(0)).intValue();
                tam_prox=v[prox_cidade-1].size();
                System.out.print("*** Prox: "+prox_cidade+" tamanho:"+tam_prox);
                for(i=1;i<v[cid_corrente-1].size();i++) {
                    j=((Integer) v[cid_corrente-1].get(i)).intValue();
                    if (v[j-1].size()<tam_prox) {
                        prox_cidade=j;
                        tam_prox=v[j-1].size();
                        System.out.print("Prox: "+prox_cidade+" tamanho:"+tam_prox);
                    }                    
                }                
            } else {
                //N�o h� nenhuma cidade na lista de adjac�ncias                
                prox_cidade=-1;
                for(i=1;((prox_cidade<0)&&(i<tam));i++) {
                    if (ja_usadas.indexOf(new Integer(i))<0) {
                        prox_cidade=i;
                    }
                }
                System.out.print("Como n�o havia ningu�m, prox: "+prox_cidade);
            }
            cid_corrente=prox_cidade;            
        }
        return(retorno);
    }
    
    
}
